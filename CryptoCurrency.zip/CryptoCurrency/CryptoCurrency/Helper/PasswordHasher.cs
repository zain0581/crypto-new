﻿namespace CryptoCurrency.Helper
{
    public class PasswordHasher
    {
        private static RNGCryptoServiceProvider rng = new RNGCryptoServiceProvider();
        private static readonly int SaltSize = 16;
        private static readonly int HashSize = 20;
        private static readonly int Ietrations = 1000;
    }

    internal class RNGCryptoServiceProvider
    {
    }
}
