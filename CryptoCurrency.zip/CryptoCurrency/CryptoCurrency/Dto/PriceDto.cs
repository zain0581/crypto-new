﻿namespace CryptoCurrency.Dto
{
    public class PriceDto
    {
        public int Id { get; set; }
        public int CoinId { get; set; }
        public decimal Value { get; set; }
    }
}
