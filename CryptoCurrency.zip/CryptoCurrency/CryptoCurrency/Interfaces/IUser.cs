﻿using CryptoCurrency.Models;

namespace CryptoCurrency.Interfaces
{
    public interface IUser
    {
        //ICollection<User> GetUsers();
        //User GetUser(int id);

        //void CreateUser(User userobj);
        //void UpdateUser(User userobj);
        //void DeleteUser(User userobj);

       
            ICollection<User> GetUsers();
            User GetUser(int id);
        void CreateUser(User userobj);
            void UpdateUser(User userobj);
            void DeleteUser(User userobj);
            User Authenticate(string Email, string Password);
        //bool ValidatePassword(string password, out string errorMessage);





    }
}
