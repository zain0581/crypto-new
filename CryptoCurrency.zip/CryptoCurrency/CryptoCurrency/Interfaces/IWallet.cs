﻿namespace CryptoCurrency.Interfaces
{
    public interface IWallet
    {
    }
}
